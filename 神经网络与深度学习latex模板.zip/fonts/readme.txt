Please download these fonts with bootstrap.sh or by yourself.

.
├── NotoSansCJKsc-Black.otf
├── NotoSansCJKsc-Bold.otf
├── NotoSansCJKsc-DemiLight.otf
├── NotoSansCJKsc-Light.otf
├── NotoSansCJKsc-Medium.otf
├── NotoSansCJKsc-Regular.otf
├── NotoSansCJKsc-Thin.otf
├── NotoSansMonoCJKsc-Bold.otf
├── NotoSansMonoCJKsc-Regular.otf
├── Roboto-Black.ttf
├── Roboto-BlackItalic.ttf
├── Roboto-Bold.ttf
├── Roboto-BoldItalic.ttf
├── Roboto-Italic.ttf
├── Roboto-Light.ttf
├── Roboto-LightItalic.ttf
├── Roboto-Medium.ttf
├── Roboto-MediumItalic.ttf
├── Roboto-Regular.ttf
├── Roboto-Thin.ttf
├── Roboto-ThinItalic.ttf
├── RobotoCondensed-Bold.ttf
├── RobotoCondensed-BoldItalic.ttf
├── RobotoCondensed-Italic.ttf
├── RobotoCondensed-Light.ttf
├── RobotoCondensed-LightItalic.ttf
├── RobotoCondensed-Regular.ttf
├── SourceCodePro-Black.otf
├── SourceCodePro-BlackIt.otf
├── SourceCodePro-Bold.otf
├── SourceCodePro-BoldIt.otf
├── SourceCodePro-ExtraLight.otf
├── SourceCodePro-ExtraLightIt.otf
├── SourceCodePro-It.otf
├── SourceCodePro-Light.otf
├── SourceCodePro-LightIt.otf
├── SourceCodePro-Medium.otf
├── SourceCodePro-MediumIt.otf
├── SourceCodePro-Regular.otf
├── SourceCodePro-Semibold.otf
├── SourceCodePro-SemiboldIt.otf
├── SourceSerifPro-Black.otf
├── SourceSerifPro-Bold.otf
├── SourceSerifPro-ExtraLight.otf
├── SourceSerifPro-Light.otf
├── SourceSerifPro-Regular.otf
└── SourceSerifPro-Semibold.otf

0 directories, 47 files
